-- Create function to process withdrawal
CREATE OR REPLACE FUNCTION process_withdrawal(
  p_user_id uuid,
  p_wallet_id uuid,
  p_amount numeric,
  p_withdrawal_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Start transaction
  INSERT INTO beta_game_transactions (
    wallet_id,
    type,
    amount,
    game_id
  ) VALUES (
    p_wallet_id,
    'withdraw',
    p_amount,
    p_withdrawal_id
  );

  -- Update wallet balance
  UPDATE beta_game_wallets
  SET 
    balance = balance - p_amount,
    updated_at = CURRENT_TIMESTAMP
  WHERE id = p_wallet_id;
END;
$$;

-- Create table for withdrawal webhooks
CREATE TABLE IF NOT EXISTS withdrawal_webhooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  withdrawal_id text NOT NULL,
  status text NOT NULL,
  payload jsonb NOT NULL,
  processed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE withdrawal_webhooks ENABLE ROW LEVEL SECURITY;

-- Add policy for service role
CREATE POLICY "Sistema pode gerenciar webhooks de saque"
  ON withdrawal_webhooks
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_withdrawal_webhooks_withdrawal_id 
ON withdrawal_webhooks(withdrawal_id);

CREATE INDEX IF NOT EXISTS idx_withdrawal_webhooks_status 
ON withdrawal_webhooks(status);