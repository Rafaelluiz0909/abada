/*
  # Fix Referral Relationships

  1. Changes
    - Add foreign key relationships for referral_rewards table
    - Update RLS policies to use proper table references
    - Fix ambiguous column references in queries
*/

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Usuários podem ver suas recompensas" ON referral_rewards;

-- Add explicit foreign key relationships
ALTER TABLE referral_rewards
DROP CONSTRAINT IF EXISTS referral_rewards_referred_id_fkey,
ADD CONSTRAINT referral_rewards_referred_id_fkey 
  FOREIGN KEY (referred_id) 
  REFERENCES auth.users(id);

-- Recreate policies with proper table references
CREATE POLICY "Usuários podem ver suas recompensas"
  ON referral_rewards FOR SELECT
  TO authenticated
  USING (auth.uid() = referral_rewards.referrer_id);

-- Add index to improve join performance
CREATE INDEX IF NOT EXISTS idx_referral_rewards_referred_id 
  ON referral_rewards(referred_id);

-- Add index for referrer_id to improve query performance
CREATE INDEX IF NOT EXISTS idx_referral_rewards_referrer_id 
  ON referral_rewards(referrer_id);