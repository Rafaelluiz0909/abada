/*
  # Fix Referral Relationships and Policies

  1. Changes
    - Drop and recreate foreign key relationships
    - Update RLS policies
    - Add necessary indexes
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Usuários podem ver suas recompensas" ON referral_rewards;

-- Drop and recreate foreign key relationships
ALTER TABLE referral_rewards 
DROP CONSTRAINT IF EXISTS referral_rewards_referred_id_fkey,
DROP CONSTRAINT IF EXISTS referral_rewards_referrer_id_fkey,
DROP CONSTRAINT IF EXISTS referral_rewards_payment_id_fkey;

-- Recreate foreign key relationships with explicit references
ALTER TABLE referral_rewards
ADD CONSTRAINT referral_rewards_referred_id_fkey 
  FOREIGN KEY (referred_id) 
  REFERENCES auth.users(id),
ADD CONSTRAINT referral_rewards_referrer_id_fkey 
  FOREIGN KEY (referrer_id) 
  REFERENCES auth.users(id),
ADD CONSTRAINT referral_rewards_payment_id_fkey 
  FOREIGN KEY (payment_id) 
  REFERENCES payments(id);

-- Recreate policies with proper table references
CREATE POLICY "Usuários podem ver suas recompensas"
  ON referral_rewards FOR SELECT
  TO authenticated
  USING (auth.uid() = referrer_id);

-- Drop existing indexes
DROP INDEX IF EXISTS idx_referral_rewards_referred_id;
DROP INDEX IF EXISTS idx_referral_rewards_referrer_id;
DROP INDEX IF EXISTS idx_referral_rewards_payment_id;

-- Create optimized indexes
CREATE INDEX idx_referral_rewards_referred_id 
  ON referral_rewards(referred_id);

CREATE INDEX idx_referral_rewards_referrer_id 
  ON referral_rewards(referrer_id);

CREATE INDEX idx_referral_rewards_payment_id 
  ON referral_rewards(payment_id);