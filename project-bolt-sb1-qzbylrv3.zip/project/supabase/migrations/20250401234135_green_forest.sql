/*
  # Fix Payment Webhook Policies

  1. Changes
    - Drop existing webhook policy
    - Recreate webhook policy with correct permissions
    - Add missing indexes for performance
*/

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Sistema pode gerenciar webhooks" ON payment_webhooks;

-- Recreate the policy with correct permissions
CREATE POLICY "Sistema pode gerenciar webhooks v2"
  ON payment_webhooks
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Add missing indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payment_webhooks_transaction_id 
  ON payment_webhooks(transaction_id);

CREATE INDEX IF NOT EXISTS idx_payment_webhooks_payment_id 
  ON payment_webhooks(payment_id);

-- Ensure RLS is enabled
ALTER TABLE payment_webhooks ENABLE ROW LEVEL SECURITY;