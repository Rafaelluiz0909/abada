/*
  # Fix Wallet Policies

  1. Changes
    - Add INSERT policy for wallet creation
    - Add UPDATE policy for wallet balance updates
*/

-- Add policy for wallet creation
CREATE POLICY "Usuários podem criar sua carteira"
  ON beta_game_wallets
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Add policy for wallet updates
CREATE POLICY "Sistema pode atualizar carteiras"
  ON beta_game_wallets
  FOR UPDATE
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Add policy for transaction creation
CREATE POLICY "Sistema pode criar transações"
  ON beta_game_transactions
  FOR INSERT
  TO service_role
  WITH CHECK (true);