/*
  # Give Monthly Plan to User

  1. Changes
    - Updates user's profile with "Plano Mensal" plan type
    - Sets expiration date to 30 days from now
*/

DO $$
DECLARE
  user_id uuid;
BEGIN
  -- Get user ID by email
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'joao023@gmail.com';

  IF user_id IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Update user's plan using admin_update_plan function
  PERFORM admin_update_plan('joao023@gmail.com', 'Plano Mensal', 720);
END $$;