/*
  # Add name field to profiles table

  1. Changes
    - Add name column to profiles table
    - Update handle_new_user function to include name
*/

-- Add name column to profiles table
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS name text;

-- Update handle_new_user function to include name
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;