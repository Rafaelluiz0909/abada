/*
  # Fix Referral Code System

  1. Changes
    - Drop and recreate functions with fixed parameter names
    - Update policies for better access control
    - Fix ambiguous column references

  2. Security
    - Maintain RLS policies
    - Ensure proper access control
*/

-- Drop existing functions to avoid conflicts
DROP FUNCTION IF EXISTS generate_referral_code(uuid);
DROP FUNCTION IF EXISTS process_referral(uuid, text);

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Usuários podem ver seu próprio código" ON referral_codes;
DROP POLICY IF EXISTS "Usuários podem criar seu código" ON referral_codes;
DROP POLICY IF EXISTS "Usuários podem atualizar seu código" ON referral_codes;
DROP POLICY IF EXISTS "Usuários podem ver suas recompensas" ON referral_rewards;

-- Recreate policies with better specificity
CREATE POLICY "Usuários podem ver seu próprio código"
  ON referral_codes FOR SELECT
  TO authenticated
  USING (auth.uid() = referral_codes.user_id);

CREATE POLICY "Usuários podem criar seu código"
  ON referral_codes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar seu código"
  ON referral_codes FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem ver suas recompensas"
  ON referral_rewards FOR SELECT
  TO authenticated
  USING (auth.uid() = referral_rewards.referrer_id);

-- Recreate generate_referral_code function with fixed parameter name
CREATE OR REPLACE FUNCTION public.generate_referral_code(p_user_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_code text;
  v_exists boolean;
  v_max_attempts integer := 10;
  v_current_attempt integer := 0;
BEGIN
  -- Check if user already has a code
  SELECT code INTO v_code
  FROM referral_codes
  WHERE user_id = p_user_id;
  
  IF v_code IS NOT NULL THEN
    RETURN v_code;
  END IF;

  LOOP
    EXIT WHEN v_current_attempt >= v_max_attempts;
    v_current_attempt := v_current_attempt + 1;
    
    -- Generate random 8-character code
    v_code := upper(substring(md5(random()::text) from 1 for 8));
    
    -- Check if code exists
    SELECT EXISTS (
      SELECT 1 FROM referral_codes WHERE code = v_code
    ) INTO v_exists;
    
    IF NOT v_exists THEN
      -- Insert new code
      INSERT INTO referral_codes (user_id, code)
      VALUES (p_user_id, v_code)
      ON CONFLICT (user_id) DO UPDATE
      SET code = EXCLUDED.code
      RETURNING code INTO v_code;
      
      RETURN v_code;
    END IF;
  END LOOP;

  RAISE EXCEPTION 'Could not generate unique code after % attempts', v_max_attempts;
END;
$$;

-- Recreate process_referral function with fixed parameter names
CREATE OR REPLACE FUNCTION public.process_referral(
  p_payment_id uuid,
  p_referral_code text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_referrer_id uuid;
  v_referred_id uuid;
  v_plan_price numeric;
  v_reward_hours integer;
BEGIN
  -- Get referrer and referred IDs with explicit table references
  SELECT rc.user_id, p.user_id, pl.price
  INTO v_referrer_id, v_referred_id, v_plan_price
  FROM payments p
  JOIN referral_codes rc ON rc.code = p_referral_code
  JOIN plans pl ON pl.id = p.plan_id
  WHERE p.id = p_payment_id;

  IF v_referrer_id IS NULL OR v_referred_id IS NULL THEN
    RAISE EXCEPTION 'Invalid referral data';
  END IF;

  -- Calculate reward hours (R$10 = 1 hour)
  v_reward_hours := (v_plan_price / 10)::integer;

  -- Create reward record
  INSERT INTO referral_rewards (
    referrer_id,
    referred_id,
    payment_id,
    reward_hours
  ) VALUES (
    v_referrer_id,
    v_referred_id,
    p_payment_id,
    v_reward_hours
  );

  -- Extend referrer's plan
  UPDATE profiles
  SET plan_expires_at = GREATEST(
    COALESCE(plan_expires_at, CURRENT_TIMESTAMP),
    CURRENT_TIMESTAMP
  ) + (v_reward_hours || ' hours')::interval
  WHERE id = v_referrer_id;

  -- Mark reward as processed
  UPDATE referral_rewards
  SET processed = true
  WHERE payment_id = p_payment_id;
END;
$$;