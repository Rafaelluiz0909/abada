/*
  # Funções Administrativas para Gerenciamento de Planos

  1. Novas Funções
    - `admin_extend_plan`: Estende manualmente o plano de um usuário
    - `admin_cancel_plan`: Cancela o plano de um usuário
    - `admin_update_plan`: Atualiza o tipo de plano de um usuário

  2. Segurança
    - Funções restritas ao papel de administrador (service_role)
    - Validações de dados de entrada
*/

-- Função para estender o plano de um usuário
CREATE OR REPLACE FUNCTION admin_extend_plan(
  user_email TEXT,
  hours INTEGER
)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_user_id UUID;
  current_expires_at TIMESTAMPTZ;
BEGIN
  -- Encontrar o ID do usuário pelo email
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = user_email;

  IF target_user_id IS NULL THEN
    RETURN 'Usuário não encontrado';
  END IF;

  -- Buscar data de expiração atual
  SELECT plan_expires_at INTO current_expires_at
  FROM profiles
  WHERE id = target_user_id;

  -- Atualizar a data de expiração
  UPDATE profiles
  SET 
    plan_expires_at = COALESCE(
      GREATEST(current_expires_at, CURRENT_TIMESTAMP),
      CURRENT_TIMESTAMP
    ) + (hours || ' hours')::interval
  WHERE id = target_user_id;

  RETURN 'Plano estendido com sucesso';
END;
$$;

-- Função para cancelar o plano de um usuário
CREATE OR REPLACE FUNCTION admin_cancel_plan(
  user_email TEXT
)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_user_id UUID;
BEGIN
  -- Encontrar o ID do usuário pelo email
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = user_email;

  IF target_user_id IS NULL THEN
    RETURN 'Usuário não encontrado';
  END IF;

  -- Cancelar o plano
  UPDATE profiles
  SET 
    plan_type = NULL,
    plan_expires_at = NULL
  WHERE id = target_user_id;

  -- Cancelar assinaturas ativas
  UPDATE subscriptions
  SET status = 'cancelled'
  WHERE user_id = target_user_id
  AND status = 'active';

  RETURN 'Plano cancelado com sucesso';
END;
$$;

-- Função para atualizar o tipo de plano de um usuário
CREATE OR REPLACE FUNCTION admin_update_plan(
  user_email TEXT,
  new_plan_name TEXT,
  duration_hours INTEGER
)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_user_id UUID;
  plan_exists BOOLEAN;
BEGIN
  -- Verificar se o plano existe
  SELECT EXISTS (
    SELECT 1 FROM plans WHERE name = new_plan_name
  ) INTO plan_exists;

  IF NOT plan_exists THEN
    RETURN 'Plano não encontrado';
  END IF;

  -- Encontrar o ID do usuário pelo email
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = user_email;

  IF target_user_id IS NULL THEN
    RETURN 'Usuário não encontrado';
  END IF;

  -- Atualizar o plano
  UPDATE profiles
  SET 
    plan_type = new_plan_name,
    plan_expires_at = CURRENT_TIMESTAMP + (duration_hours || ' hours')::interval
  WHERE id = target_user_id;

  RETURN 'Plano atualizado com sucesso';
END;
$$;

-- Comentários de uso
COMMENT ON FUNCTION admin_extend_plan IS 'Estende o plano de um usuário por um número específico de horas. Exemplo: SELECT admin_extend_plan(''usuario@email.com'', 24);';
COMMENT ON FUNCTION admin_cancel_plan IS 'Cancela o plano atual de um usuário. Exemplo: SELECT admin_cancel_plan(''usuario@email.com'');';
COMMENT ON FUNCTION admin_update_plan IS 'Atualiza o tipo de plano de um usuário. Exemplo: SELECT admin_update_plan(''usuario@email.com'', ''Plano Mensal'', 720);';

-- Garantir que apenas administradores possam executar estas funções
REVOKE ALL ON FUNCTION admin_extend_plan FROM PUBLIC;
REVOKE ALL ON FUNCTION admin_cancel_plan FROM PUBLIC;
REVOKE ALL ON FUNCTION admin_update_plan FROM PUBLIC;

GRANT EXECUTE ON FUNCTION admin_extend_plan TO service_role;
GRANT EXECUTE ON FUNCTION admin_cancel_plan TO service_role;
GRANT EXECUTE ON FUNCTION admin_update_plan TO service_role;