/*
  # Ativar plano de teste para usuário específico

  1. Alterações
    - Ativa o plano "Teste Rápido" para o usuário joao023@gmail.com
    - Define a duração do plano para 1 hora
*/

DO $$
DECLARE
  user_id uuid;
BEGIN
  -- Obter o ID do usuário pelo email
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'joao023@gmail.com';

  IF user_id IS NULL THEN
    RAISE EXCEPTION 'Usuário não encontrado';
  END IF;

  -- Usar a função admin_give_trial para ativar o plano
  PERFORM admin_give_trial('joao023@gmail.com');
END $$;