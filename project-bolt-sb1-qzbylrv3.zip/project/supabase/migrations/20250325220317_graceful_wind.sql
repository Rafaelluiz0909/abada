/*
  # Sistema de Pagamentos e Planos

  1. Novas Tabelas
    - `payments`: Registra todos os pagamentos
    - `plans`: Catálogo de planos disponíveis
    - `subscriptions`: Gerencia assinaturas ativas

  2. Alterações
    - Adiciona novas colunas na tabela `profiles`
    - Configura relacionamentos entre tabelas

  3. Segurança
    - Políticas RLS para todas as tabelas
    - Proteção de dados sensíveis
*/

-- Criar tabela de planos
CREATE TABLE IF NOT EXISTS plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price numeric(10,2) NOT NULL,
  duration_hours integer NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar tabela de pagamentos
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  plan_id uuid REFERENCES plans(id) NOT NULL,
  amount numeric(10,2) NOT NULL,
  payment_code text,
  status text DEFAULT 'pending',
  paid_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'approved', 'cancelled', 'refunded'))
);

-- Criar tabela de assinaturas
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  plan_id uuid REFERENCES plans(id) NOT NULL,
  payment_id uuid REFERENCES payments(id) NOT NULL,
  status text DEFAULT 'active',
  starts_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('active', 'expired', 'cancelled'))
);

-- Habilitar RLS
ALTER TABLE plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Políticas para planos
CREATE POLICY "Todos podem ver planos ativos" ON plans
  FOR SELECT USING (active = true);

-- Políticas para pagamentos
CREATE POLICY "Usuários podem ver seus próprios pagamentos" ON payments
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem criar seus pagamentos" ON payments
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Políticas para assinaturas
CREATE POLICY "Usuários podem ver suas próprias assinaturas" ON subscriptions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Triggers para updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_plans_updated_at
  BEFORE UPDATE ON plans
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Inserir planos padrão
INSERT INTO plans (name, description, price, duration_hours) VALUES
  ('Teste Rápido', '1 hora de funções liberadas', 10, 1),
  ('Plano Semanal', '10 dias de funções liberadas', 70, 240),
  ('Plano Mensal', 'Um mês de funções liberadas', 120, 720),
  ('Plano Trimestral', '3 meses de funções liberadas', 300, 2160),
  ('Acesso Vitalício', 'Acesso vitalício a todas as funções', 500, 87600)
ON CONFLICT DO NOTHING;

-- Função para processar pagamento aprovado
CREATE OR REPLACE FUNCTION process_approved_payment()
RETURNS TRIGGER AS $$
BEGIN
  -- Se o pagamento foi aprovado
  IF NEW.status = 'approved' AND OLD.status = 'pending' THEN
    -- Criar ou atualizar assinatura
    INSERT INTO subscriptions (
      user_id,
      plan_id,
      payment_id,
      expires_at
    ) VALUES (
      NEW.user_id,
      NEW.plan_id,
      NEW.id,
      NEW.expires_at
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para processar pagamento
CREATE TRIGGER payment_approved_trigger
  AFTER UPDATE ON payments
  FOR EACH ROW
  WHEN (NEW.status = 'approved' AND OLD.status = 'pending')
  EXECUTE FUNCTION process_approved_payment();