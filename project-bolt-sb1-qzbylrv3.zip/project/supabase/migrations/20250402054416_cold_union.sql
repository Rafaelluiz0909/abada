/*
  # Fix Payment Processing System

  1. Changes
    - Add transaction_id to payments table
    - Add indexes for better performance
    - Update payment processing function
    - Fix policies and constraints
*/

-- Add transaction_id column if not exists
ALTER TABLE payments
ADD COLUMN IF NOT EXISTS transaction_id text;

-- Create index on transaction_id
CREATE INDEX IF NOT EXISTS idx_payments_transaction_id 
ON payments(transaction_id);

-- Drop and recreate function to handle payment processing
CREATE OR REPLACE FUNCTION process_approved_payment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_wallet_id uuid;
  v_amount numeric(10,2);
BEGIN
  -- Log início do processamento
  RAISE NOTICE 'Processando pagamento ID: %, Status: %', NEW.id, NEW.status;

  -- Se o pagamento foi aprovado
  IF NEW.status = 'completed' AND OLD.status = 'pending' THEN
    -- Se for um depósito
    IF NEW.metadata->>'type' = 'deposit' THEN
      RAISE NOTICE 'Processando depósito de R$ % para usuário %', NEW.amount, NEW.user_id;

      -- Buscar ou criar carteira
      SELECT id INTO v_wallet_id
      FROM beta_game_wallets
      WHERE user_id = NEW.user_id;

      IF v_wallet_id IS NULL THEN
        -- Criar nova carteira
        INSERT INTO beta_game_wallets (
          user_id,
          balance,
          total_wagered,
          can_withdraw
        ) VALUES (
          NEW.user_id,
          NEW.amount,
          0,
          false
        )
        RETURNING id INTO v_wallet_id;
        
        RAISE NOTICE 'Nova carteira criada: %', v_wallet_id;
      ELSE
        -- Atualizar carteira existente
        UPDATE beta_game_wallets
        SET 
          balance = balance + NEW.amount,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = v_wallet_id;
        
        RAISE NOTICE 'Carteira atualizada: %', v_wallet_id;
      END IF;

      -- Registrar transação
      INSERT INTO beta_game_transactions (
        wallet_id,
        type,
        amount
      ) VALUES (
        v_wallet_id,
        'deposit',
        NEW.amount
      );
      
      RAISE NOTICE 'Transação registrada para carteira %', v_wallet_id;
    END IF;
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Erro ao processar pagamento: % %', SQLERRM, SQLSTATE;
    RETURN NEW;
END;
$$;

-- Recreate trigger
DROP TRIGGER IF EXISTS payment_approved_trigger ON payments;
CREATE TRIGGER payment_approved_trigger
  AFTER UPDATE ON payments
  FOR EACH ROW
  WHEN (NEW.status = 'completed' AND OLD.status = 'pending')
  EXECUTE FUNCTION process_approved_payment();

-- Update policies to ensure proper access
DROP POLICY IF EXISTS "Sistema pode processar pagamentos" ON payments;
CREATE POLICY "Sistema pode processar pagamentos"
  ON payments
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Add policy for service role to manage wallets
DROP POLICY IF EXISTS "Sistema pode gerenciar carteiras" ON beta_game_wallets;
CREATE POLICY "Sistema pode gerenciar carteiras"
  ON beta_game_wallets
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Add policy for service role to manage transactions
DROP POLICY IF EXISTS "Sistema pode gerenciar transações" ON beta_game_transactions;
CREATE POLICY "Sistema pode gerenciar transações"
  ON beta_game_transactions
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);