/*
  # Criação da tabela de perfis e configurações de planos

  1. Nova Tabela
    - `profiles`
      - `id` (uuid, chave primária)
      - `email` (text, não nulo)
      - `plan_type` (text, pode ser nulo)
      - `plan_expires_at` (timestamp com timezone, pode ser nulo)
      - `created_at` (timestamp com timezone, default now())
      - `updated_at` (timestamp com timezone, default now())

  2. Segurança
    - Habilita RLS na tabela profiles
    - Adiciona políticas para leitura e atualização
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text NOT NULL,
  plan_type text,
  plan_expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Política para usuários lerem seus próprios dados
CREATE POLICY "Usuários podem ler seus próprios dados"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Política para usuários atualizarem seus próprios dados
CREATE POLICY "Usuários podem atualizar seus próprios dados"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Trigger para atualizar o updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();