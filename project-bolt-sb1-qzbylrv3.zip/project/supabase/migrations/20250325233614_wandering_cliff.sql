/*
  # Remoção do Sistema de Afiliação

  1. Alterações
    - Remove todas as tabelas relacionadas a afiliação
    - Remove funções e triggers associados
    - Remove políticas de segurança
    - Remove coluna de código de indicação da tabela payments
*/

-- Remover triggers
DROP TRIGGER IF EXISTS handle_payment_referral_trigger ON payments;
DROP TRIGGER IF EXISTS process_referral_trigger ON payments;

-- Remover funções
DROP FUNCTION IF EXISTS handle_payment_referral();
DROP FUNCTION IF EXISTS process_referral_after_payment();
DROP FUNCTION IF EXISTS process_referral(uuid, text);
DROP FUNCTION IF EXISTS generate_referral_code(uuid);

-- Remover índices
DROP INDEX IF EXISTS idx_referral_rewards_referred_id;
DROP INDEX IF EXISTS idx_referral_rewards_referrer_id;
DROP INDEX IF EXISTS idx_referral_rewards_payment_id;
DROP INDEX IF EXISTS idx_referral_codes_user_id;
DROP INDEX IF EXISTS idx_referral_codes_code;
DROP INDEX IF EXISTS idx_payments_referral_code;

-- Remover coluna de código de indicação da tabela payments
ALTER TABLE payments DROP COLUMN IF EXISTS referral_code;

-- Remover tabelas
DROP TABLE IF EXISTS referral_rewards CASCADE;
DROP TABLE IF EXISTS referral_codes CASCADE;