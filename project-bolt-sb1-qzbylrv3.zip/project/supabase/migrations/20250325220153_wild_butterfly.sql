/*
  # Adicionar colunas de plano e atualizar usuário específico

  1. Alterações
    - Adiciona coluna `plan_type` na tabela `profiles`
    - Adiciona coluna `plan_expires_at` na tabela `profiles`
    - Atualiza o plano do usuário específico

  2. Segurança
    - Mantém as políticas de RLS existentes
*/

-- Adicionar colunas para gerenciamento de planos se não existirem
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS plan_type text,
ADD COLUMN IF NOT EXISTS plan_expires_at timestamptz;

-- Atualizar o plano do usuário específico
DO $$
DECLARE
  user_id uuid;
  expiration_time timestamptz;
BEGIN
  -- Obter o ID do usuário pelo email
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'rafaelluiz.hernandes0909@gmail.com';

  -- Definir o tempo de expiração (2 horas a partir de agora)
  expiration_time := NOW() + INTERVAL '2 hours';

  -- Atualizar o perfil do usuário
  UPDATE profiles
  SET 
    plan_type = 'Teste Rápido',
    plan_expires_at = expiration_time
  WHERE id = user_id;
END $$;