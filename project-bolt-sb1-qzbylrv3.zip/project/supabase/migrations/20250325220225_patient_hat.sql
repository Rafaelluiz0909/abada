/*
  # Adicionar coluna updated_at e atualizar plano do usuário

  1. Alterações
    - Adiciona coluna `updated_at` na tabela `profiles`
    - Atualiza o plano do usuário específico

  2. Segurança
    - Mantém as políticas de RLS existentes
*/

-- Adicionar coluna updated_at se não existir
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- Atualizar o plano do usuário específico
DO $$
DECLARE
  user_id uuid;
  expiration_time timestamptz;
BEGIN
  -- Obter o ID do usuário pelo email
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'rafaelluiz.hernandes0909@gmail.com';

  -- Definir o tempo de expiração (2 horas a partir de agora)
  expiration_time := NOW() + INTERVAL '2 hours';

  -- Atualizar o perfil do usuário
  UPDATE profiles
  SET 
    plan_type = 'Teste Rápido',
    plan_expires_at = expiration_time,
    updated_at = NOW()
  WHERE id = user_id;
END $$;