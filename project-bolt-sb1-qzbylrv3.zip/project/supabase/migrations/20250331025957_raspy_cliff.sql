/*
  # Sistema de Acesso PVP

  1. Nova Tabela
    - `pvp_access_requests`: Armazena solicitações de acesso aos jogos PVP
      - `id` (uuid, chave primária)
      - `user_id` (uuid, referência ao usuário)
      - `email` (text, email do usuário)
      - `name` (text, nome do usuário)
      - `status` (text, status da solicitação)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Segurança
    - RLS habilitado
    - Políticas de acesso específicas
*/

-- Criar tabela de solicitações de acesso
CREATE TABLE pvp_access_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  email text NOT NULL,
  name text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Habilitar RLS
ALTER TABLE pvp_access_requests ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso
CREATE POLICY "Usuários podem ver suas próprias solicitações"
  ON pvp_access_requests
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem criar solicitações"
  ON pvp_access_requests
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Trigger para atualizar updated_at
CREATE TRIGGER update_pvp_access_requests_updated_at
  BEFORE UPDATE ON pvp_access_requests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Criar índices
CREATE INDEX idx_pvp_access_requests_user_id ON pvp_access_requests(user_id);
CREATE INDEX idx_pvp_access_requests_status ON pvp_access_requests(status);