/*
  # Fix Payment Plan ID Constraint

  1. Changes
    - Make plan_id nullable in payments table
    - Add check constraint to ensure plan_id is present for plan payments
    - Update existing policies
*/

-- Make plan_id nullable
ALTER TABLE payments 
ALTER COLUMN plan_id DROP NOT NULL;

-- Add check constraint to ensure plan_id is present for plan payments
ALTER TABLE payments
ADD CONSTRAINT check_plan_id_for_plan_payments
CHECK (
  (metadata->>'type' = 'deposit') OR 
  (metadata->>'type' IS NULL AND plan_id IS NOT NULL)
);

-- Update policies to handle both plan payments and deposits
DROP POLICY IF EXISTS "Usuários podem criar seus pagamentos" ON payments;
CREATE POLICY "Usuários podem criar seus pagamentos"
  ON payments
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND (
      (metadata->>'type' = 'deposit') OR
      (metadata->>'type' IS NULL AND plan_id IS NOT NULL)
    )
  );