/*
  # Correção das Políticas RLS e Perfis

  1. Alterações
    - Corrige políticas RLS para payments
    - Adiciona políticas para usuários autenticados
    - Garante criação automática de perfil
*/

-- Remover políticas existentes
DROP POLICY IF EXISTS "Usuários podem ver seus próprios pagamentos" ON payments;
DROP POLICY IF EXISTS "Usuários podem criar seus pagamentos" ON payments;
DROP POLICY IF EXISTS "Sistema pode processar pagamentos" ON payments;

-- Criar novas políticas para payments
CREATE POLICY "Usuários podem ver seus próprios pagamentos"
  ON payments
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem criar seus pagamentos"
  ON payments
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND (
      (metadata->>'type' = 'deposit') OR
      (metadata->>'type' IS NULL AND plan_id IS NOT NULL)
    )
  );

CREATE POLICY "Sistema pode processar pagamentos"
  ON payments
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Atualizar função de criação de perfil
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1))
  )
  ON CONFLICT (id) DO UPDATE
  SET
    email = EXCLUDED.email,
    name = COALESCE(EXCLUDED.name, profiles.name);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recriar trigger para criação de perfil
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Criar perfis faltantes para usuários existentes
INSERT INTO profiles (id, email, name)
SELECT 
  id,
  email,
  COALESCE(raw_user_meta_data->>'name', split_part(email, '@', 1))
FROM auth.users
WHERE NOT EXISTS (
  SELECT 1 FROM profiles WHERE profiles.id = users.id
)
ON CONFLICT (id) DO NOTHING;