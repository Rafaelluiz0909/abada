/*
  # Correção da Ordem de Drop da Função

  1. Alterações
    - Remove o trigger antes da função
    - Recria a função e o trigger na ordem correta
*/

-- Primeiro, remover o trigger que depende da função
DROP TRIGGER IF EXISTS payment_approved_trigger ON payments;

-- Agora podemos remover a função com segurança
DROP FUNCTION IF EXISTS process_approved_payment();

-- Recriar a função com as melhorias
CREATE OR REPLACE FUNCTION process_approved_payment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_plan_name text;
  v_plan_duration integer;
BEGIN
  -- Log início do processamento
  RAISE NOTICE 'Iniciando processamento de pagamento: %', NEW.id;

  -- Buscar informações do plano
  SELECT name, duration_hours INTO v_plan_name, v_plan_duration
  FROM plans 
  WHERE id = NEW.plan_id;

  IF v_plan_name IS NULL THEN
    RAISE EXCEPTION 'Plano não encontrado para o pagamento %', NEW.id;
  END IF;

  -- Log informações do plano
  RAISE NOTICE 'Plano encontrado: % (% horas)', v_plan_name, v_plan_duration;

  -- Se o pagamento foi aprovado
  IF NEW.status = 'completed' AND OLD.status = 'pending' THEN
    -- Log mudança de status
    RAISE NOTICE 'Pagamento aprovado, atualizando perfil do usuário';

    -- Atualizar perfil do usuário
    UPDATE profiles
    SET 
      plan_type = v_plan_name,
      plan_expires_at = CURRENT_TIMESTAMP + (v_plan_duration || ' hours')::interval,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.user_id;

    -- Verificar se o perfil foi atualizado
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Falha ao atualizar perfil do usuário %', NEW.user_id;
    END IF;

    -- Log atualização do perfil
    RAISE NOTICE 'Perfil atualizado com sucesso';

    -- Criar ou atualizar assinatura
    INSERT INTO subscriptions (
      user_id,
      plan_id,
      payment_id,
      status,
      expires_at
    ) VALUES (
      NEW.user_id,
      NEW.plan_id,
      NEW.id,
      'active',
      CURRENT_TIMESTAMP + (v_plan_duration || ' hours')::interval
    )
    ON CONFLICT (user_id, payment_id) 
    DO UPDATE SET
      status = 'active',
      expires_at = CURRENT_TIMESTAMP + (v_plan_duration || ' hours')::interval;

    -- Log criação da assinatura
    RAISE NOTICE 'Assinatura criada/atualizada com sucesso';
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log erro detalhado
    RAISE NOTICE 'Erro no processamento do pagamento: % %', SQLERRM, SQLSTATE;
    RETURN NEW;
END;
$$;

-- Recriar o trigger
CREATE TRIGGER payment_approved_trigger
  AFTER UPDATE ON payments
  FOR EACH ROW
  WHEN (NEW.status = 'completed' AND OLD.status = 'pending')
  EXECUTE FUNCTION process_approved_payment();

-- Garantir que os índices existam
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id_payment_id ON subscriptions(user_id, payment_id);