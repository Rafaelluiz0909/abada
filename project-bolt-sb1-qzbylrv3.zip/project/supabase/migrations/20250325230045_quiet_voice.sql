/*
  # Adicionar função helper para plano inicial

  1. Nova Função
    - `admin_give_trial`: Função para dar o plano inicial de R$ 10,00 para um usuário
*/

-- Função helper para dar o plano inicial
CREATE OR REPLACE FUNCTION admin_give_trial(
  user_email TEXT
)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Usar a função admin_update_plan existente
  RETURN admin_update_plan(user_email, 'Teste Rápido', 1);
END;
$$;

-- Garantir que apenas administradores possam executar esta função
REVOKE ALL ON FUNCTION admin_give_trial FROM PUBLIC;
GRANT EXECUTE ON FUNCTION admin_give_trial TO service_role;