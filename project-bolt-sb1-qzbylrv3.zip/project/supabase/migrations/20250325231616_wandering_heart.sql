/*
  # Correção do Sistema de Indicação

  1. Alterações
    - Adiciona política para permitir inserção de códigos
    - Corrige função de geração de código
    - Garante que todas as tabelas têm as políticas necessárias

  2. Segurança
    - Mantém RLS ativo
    - Adiciona políticas faltantes
*/

-- Remover políticas existentes para recriar
DROP POLICY IF EXISTS "Usuários podem ver seu próprio código" ON referral_codes;
DROP POLICY IF EXISTS "Usuários podem ver suas recompensas" ON referral_rewards;

-- Políticas para referral_codes
CREATE POLICY "Usuários podem ver seu próprio código"
  ON referral_codes FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem criar seu código"
  ON referral_codes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar seu código"
  ON referral_codes FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Políticas para referral_rewards
CREATE POLICY "Usuários podem ver suas recompensas"
  ON referral_rewards FOR SELECT
  TO authenticated
  USING (auth.uid() = referrer_id);

-- Recriar função de geração de código com melhor tratamento de erros
CREATE OR REPLACE FUNCTION generate_referral_code(user_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_code text;
  code_exists boolean;
  max_attempts integer := 10;
  current_attempt integer := 0;
BEGIN
  -- Verificar se usuário já tem um código
  SELECT code INTO new_code
  FROM referral_codes
  WHERE referral_codes.user_id = generate_referral_code.user_id;
  
  IF new_code IS NOT NULL THEN
    RETURN new_code;
  END IF;

  LOOP
    EXIT WHEN current_attempt >= max_attempts;
    current_attempt := current_attempt + 1;
    
    -- Gerar código aleatório de 8 caracteres
    new_code := upper(substring(md5(random()::text) from 1 for 8));
    
    -- Verificar se código já existe
    SELECT EXISTS (
      SELECT 1 FROM referral_codes WHERE code = new_code
    ) INTO code_exists;
    
    -- Se código não existe, usar este
    IF NOT code_exists THEN
      -- Inserir novo código
      INSERT INTO referral_codes (user_id, code)
      VALUES (generate_referral_code.user_id, new_code)
      ON CONFLICT (user_id) DO UPDATE
      SET code = EXCLUDED.code
      RETURNING code INTO new_code;
      
      RETURN new_code;
    END IF;
  END LOOP;

  RAISE EXCEPTION 'Não foi possível gerar um código único após % tentativas', max_attempts;
END;
$$;