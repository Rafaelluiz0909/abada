/*
  # Correção do Sistema de Processamento de Pagamentos

  1. Correções
    - Garante que o trigger está ativo
    - Adiciona logs detalhados na função
    - Corrige permissões RLS
    - Adiciona índices necessários
*/

-- Verificar e corrigir permissões RLS
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Garantir que as políticas necessárias existam
DROP POLICY IF EXISTS "Sistema pode processar pagamentos" ON payments;
CREATE POLICY "Sistema pode processar pagamentos"
  ON payments
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

DROP POLICY IF EXISTS "Sistema pode atualizar perfis" ON profiles;
CREATE POLICY "Sistema pode atualizar perfis"
  ON profiles
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

DROP POLICY IF EXISTS "Sistema pode gerenciar assinaturas" ON subscriptions;
CREATE POLICY "Sistema pode gerenciar assinaturas"
  ON subscriptions
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Remover e recriar o trigger para garantir que está ativo
DROP TRIGGER IF EXISTS payment_approved_trigger ON payments;

-- Atualizar a função com mais logs e tratamento de erros
CREATE OR REPLACE FUNCTION process_approved_payment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_plan_name text;
  v_plan_duration integer;
BEGIN
  -- Log detalhado do início do processamento
  RAISE LOG 'Processando pagamento ID: %, Status Anterior: %, Novo Status: %',
    NEW.id, OLD.status, NEW.status;

  -- Verificar se temos todos os dados necessários
  IF NEW.plan_id IS NULL THEN
    RAISE LOG 'Erro: plan_id é NULL para pagamento %', NEW.id;
    RETURN NEW;
  END IF;

  IF NEW.user_id IS NULL THEN
    RAISE LOG 'Erro: user_id é NULL para pagamento %', NEW.id;
    RETURN NEW;
  END IF;

  -- Buscar informações do plano com verificação
  SELECT name, duration_hours 
  INTO v_plan_name, v_plan_duration
  FROM plans 
  WHERE id = NEW.plan_id;

  IF v_plan_name IS NULL OR v_plan_duration IS NULL THEN
    RAISE LOG 'Erro: Plano não encontrado para pagamento %. ID do plano: %',
      NEW.id, NEW.plan_id;
    RETURN NEW;
  END IF;

  RAISE LOG 'Plano encontrado: % (% horas) para pagamento %',
    v_plan_name, v_plan_duration, NEW.id;

  -- Processar apenas se for uma mudança de pending para completed
  IF NEW.status = 'completed' AND OLD.status = 'pending' THEN
    RAISE LOG 'Atualizando perfil do usuário % com plano %',
      NEW.user_id, v_plan_name;

    -- Atualizar perfil com RETURNING para confirmar atualização
    WITH updated_profile AS (
      UPDATE profiles
      SET 
        plan_type = v_plan_name,
        plan_expires_at = CURRENT_TIMESTAMP + (v_plan_duration || ' hours')::interval,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = NEW.user_id
      RETURNING id
    )
    SELECT count(*) INTO STRICT v_plan_duration
    FROM updated_profile;

    IF v_plan_duration = 0 THEN
      RAISE LOG 'Erro: Falha ao atualizar perfil do usuário %', NEW.user_id;
      RETURN NEW;
    END IF;

    RAISE LOG 'Perfil atualizado com sucesso. Criando assinatura...';

    -- Criar assinatura com RETURNING para confirmar
    WITH new_subscription AS (
      INSERT INTO subscriptions (
        user_id,
        plan_id,
        payment_id,
        status,
        expires_at
      ) VALUES (
        NEW.user_id,
        NEW.plan_id,
        NEW.id,
        'active',
        CURRENT_TIMESTAMP + (v_plan_duration || ' hours')::interval
      )
      ON CONFLICT (user_id, payment_id) 
      DO UPDATE SET
        status = 'active',
        expires_at = CURRENT_TIMESTAMP + (v_plan_duration || ' hours')::interval
      RETURNING id
    )
    SELECT count(*) INTO STRICT v_plan_duration
    FROM new_subscription;

    IF v_plan_duration = 0 THEN
      RAISE LOG 'Erro: Falha ao criar/atualizar assinatura para usuário %', NEW.user_id;
      RETURN NEW;
    END IF;

    RAISE LOG 'Assinatura criada/atualizada com sucesso para pagamento %', NEW.id;
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    RAISE LOG 'Erro não tratado no processamento do pagamento %: % %',
      NEW.id, SQLERRM, SQLSTATE;
    RETURN NEW;
END;
$$;

-- Recriar o trigger
CREATE TRIGGER payment_approved_trigger
  AFTER UPDATE ON payments
  FOR EACH ROW
  WHEN (NEW.status = 'completed' AND OLD.status = 'pending')
  EXECUTE FUNCTION process_approved_payment();

-- Garantir que todos os índices necessários existam
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_plan_id ON payments(plan_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id_payment_id ON subscriptions(user_id, payment_id);
CREATE INDEX IF NOT EXISTS idx_profiles_id ON profiles(id);

-- Verificar e corrigir constraints da tabela subscriptions
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE table_name = 'subscriptions' 
    AND constraint_name = 'subscriptions_user_id_payment_id_key'
  ) THEN
    ALTER TABLE subscriptions 
    ADD CONSTRAINT subscriptions_user_id_payment_id_key 
    UNIQUE (user_id, payment_id);
  END IF;
END $$;