/*
  # Correção do Trigger da Tabela Profiles

  1. Alterações
    - Garante que a coluna updated_at existe
    - Recria o trigger para atualização automática

  2. Segurança
    - Mantém as políticas RLS existentes
*/

-- Garantir que a coluna updated_at existe com o valor padrão correto
ALTER TABLE profiles 
ALTER COLUMN updated_at SET DEFAULT now();

-- Recriar a função do trigger (caso já exista, será substituída)
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Remover o trigger existente se houver
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;

-- Criar o novo trigger
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Atualizar o plano do usuário específico
DO $$
DECLARE
  user_id uuid;
  expiration_time timestamptz;
BEGIN
  -- Obter o ID do usuário pelo email
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'rafaelluiz.hernandes0909@gmail.com';

  -- Definir o tempo de expiração (2 horas a partir de agora)
  expiration_time := NOW() + INTERVAL '2 hours';

  -- Atualizar o perfil do usuário
  UPDATE profiles
  SET 
    plan_type = 'Teste Rápido',
    plan_expires_at = expiration_time
  WHERE id = user_id;
END $$;