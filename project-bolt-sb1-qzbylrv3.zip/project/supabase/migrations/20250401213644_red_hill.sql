/*
  # Activate All Paid Plans

  1. Changes
    - Creates functions to activate different plan types
    - Includes all plan durations:
      - 1 day (24 hours)
      - 10 days (240 hours)
      - Monthly (720 hours)
      - Quarterly (2160 hours)
      - Lifetime (87600 hours - 10 years)
*/

-- Function to activate a plan for a user
CREATE OR REPLACE FUNCTION activate_plan(
  p_email text,
  p_plan_type text,
  p_hours integer
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update user's plan
  UPDATE profiles
  SET 
    plan_type = p_plan_type,
    plan_expires_at = CURRENT_TIMESTAMP + (p_hours || ' hours')::interval,
    updated_at = CURRENT_TIMESTAMP
  WHERE id IN (
    SELECT id 
    FROM auth.users 
    WHERE email = p_email
  );

  RETURN 'Plan activated successfully';
END;
$$;

-- Replace 'user@example.com' with the actual email in each command below

-- Activate 1-day plan (24 hours)
SELECT activate_plan(
  'user@example.com',
  'Teste Rápido',
  24
);

-- Activate 10-day plan (240 hours)
SELECT activate_plan(
  'user@example.com',
  'ATLAS CHAT FULL - 10 Dias',
  240
);

-- Activate monthly plan (720 hours)
SELECT activate_plan(
  'user@example.com',
  'Plano Mensal',
  720
);

-- Activate quarterly plan (2160 hours)
SELECT activate_plan(
  'user@example.com',
  'Plano Trimestral',
  2160
);

-- Activate lifetime plan (87600 hours = 10 years)
SELECT activate_plan(
  'user@example.com',
  'Acesso Vitalício',
  87600
);

-- Log if user not found
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = 'user@example.com'
  ) THEN
    RAISE NOTICE 'No user found with the specified email';
  END IF;
END $$;