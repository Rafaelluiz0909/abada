/*
  # Add ATLAS CHAT FULL 10-day plan activation

  1. Changes
    - Creates a new migration to activate ATLAS CHAT FULL - 10 Dias plan
    - Sets expiration date to 10 days (240 hours) from activation
*/

-- Update plan directly in profiles table
UPDATE profiles
SET 
  plan_type = 'ATLAS CHAT FULL - 10 Dias',
  plan_expires_at = CURRENT_TIMESTAMP + interval '240 hours',
  updated_at = CURRENT_TIMESTAMP
WHERE id IN (
  SELECT id 
  FROM auth.users 
  WHERE email = 'user@example.com' -- Replace with actual user email
);

-- Log if user not found
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = 'user@example.com' -- Replace with actual user email
  ) THEN
    RAISE NOTICE 'No user found with the specified email';
  END IF;
END $$;