/*
  # Correção das Políticas RLS do Jogo da Velha

  1. Alterações
    - Remove políticas existentes
    - Adiciona novas políticas mais permissivas
    - Corrige permissões para criação de jogos
*/

-- Remover políticas existentes
DROP POLICY IF EXISTS "Jogadores podem ver seus jogos" ON tic_tac_toe_games;
DROP POLICY IF EXISTS "Jogadores podem atualizar seus jogos" ON tic_tac_toe_games;

-- Criar novas políticas
CREATE POLICY "Jogadores podem ver jogos disponíveis ou próprios"
  ON tic_tac_toe_games
  FOR SELECT
  TO public
  USING (
    status = 'waiting' OR 
    auth.uid() = player_x OR 
    auth.uid() = player_o
  );

CREATE POLICY "Jogadores podem criar jogos"
  ON tic_tac_toe_games
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = player_x);

CREATE POLICY "Jogadores podem atualizar seus jogos"
  ON tic_tac_toe_games
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() IN (player_x, player_o)
  )
  WITH CHECK (
    CASE
      WHEN auth.uid() = player_x AND player_o IS NULL THEN true
      WHEN auth.uid() = current_turn THEN true
      ELSE false
    END
  );