/*
  # Função para Renunciar Plano

  1. Nova Função
    - `cancel_user_plan`: Cancela o plano atual de um usuário específico
    - Remove o tipo de plano e a data de expiração
*/

-- Função para cancelar o plano de um usuário
CREATE OR REPLACE FUNCTION cancel_user_plan(
  p_email text
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Atualizar perfil do usuário removendo o plano
  UPDATE profiles
  SET 
    plan_type = NULL,
    plan_expires_at = NULL,
    updated_at = CURRENT_TIMESTAMP
  WHERE id IN (
    SELECT id 
    FROM auth.users 
    WHERE email = p_email
  );

  RETURN 'Plano cancelado com sucesso';
END;
$$;

-- Exemplo de uso (substitua pelo email real do usuário):
SELECT cancel_user_plan('email@exemplo.com');