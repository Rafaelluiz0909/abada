/*
  # Sistema de Carteira para Jogos Beta

  1. Nova Tabela
    - `beta_game_wallets`: Armazena saldo dos usuários para jogos beta
    - `beta_game_transactions`: Histórico de transações

  2. Segurança
    - RLS habilitado
    - Políticas de acesso específicas
*/

-- Criar tabela de carteiras
CREATE TABLE beta_game_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL UNIQUE,
  balance numeric(10,2) DEFAULT 0.00 NOT NULL,
  total_wagered numeric(10,2) DEFAULT 0.00 NOT NULL,
  can_withdraw boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar tabela de transações
CREATE TABLE beta_game_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id uuid REFERENCES beta_game_wallets(id) NOT NULL,
  type text NOT NULL CHECK (type IN ('deposit', 'withdraw', 'win', 'loss')),
  amount numeric(10,2) NOT NULL,
  game_id text,
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE beta_game_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE beta_game_transactions ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso
CREATE POLICY "Usuários podem ver sua própria carteira"
  ON beta_game_wallets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem ver suas próprias transações"
  ON beta_game_transactions
  FOR SELECT
  TO authenticated
  USING (
    wallet_id IN (
      SELECT id FROM beta_game_wallets WHERE user_id = auth.uid()
    )
  );

-- Função para processar resultado do jogo
CREATE OR REPLACE FUNCTION process_game_result(
  p_user_id uuid,
  p_game_id text,
  p_result text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_wallet_id uuid;
  v_amount numeric(10,2);
BEGIN
  -- Buscar carteira do usuário
  SELECT id INTO v_wallet_id
  FROM beta_game_wallets
  WHERE user_id = p_user_id;

  -- Definir valor baseado no resultado
  v_amount := CASE 
    WHEN p_result = 'win' THEN 1.00
    WHEN p_result = 'loss' THEN -1.00
    ELSE 0.00
  END;

  -- Atualizar saldo
  UPDATE beta_game_wallets
  SET 
    balance = balance + v_amount,
    total_wagered = total_wagered + ABS(v_amount),
    can_withdraw = CASE 
      WHEN total_wagered >= balance THEN true 
      ELSE false 
    END
  WHERE id = v_wallet_id;

  -- Registrar transação
  IF v_amount != 0 THEN
    INSERT INTO beta_game_transactions (
      wallet_id,
      type,
      amount,
      game_id
    ) VALUES (
      v_wallet_id,
      CASE 
        WHEN v_amount > 0 THEN 'win'
        ELSE 'loss'
      END,
      ABS(v_amount),
      p_game_id
    );
  END IF;
END;
$$;

-- Função para criar carteira
CREATE OR REPLACE FUNCTION create_wallet(p_user_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_wallet_id uuid;
BEGIN
  INSERT INTO beta_game_wallets (user_id)
  VALUES (p_user_id)
  RETURNING id INTO v_wallet_id;
  
  RETURN v_wallet_id;
END;
$$;

-- Índices
CREATE INDEX idx_wallets_user_id ON beta_game_wallets(user_id);
CREATE INDEX idx_transactions_wallet_id ON beta_game_transactions(wallet_id);