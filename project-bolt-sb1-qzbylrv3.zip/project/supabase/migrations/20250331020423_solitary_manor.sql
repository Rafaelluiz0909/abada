/*
  # Sistema de Jogo da Velha Multiplayer

  1. Novas Tabelas
    - `tic_tac_toe_games`: Armazena as partidas
    - `tic_tac_toe_moves`: Armazena os movimentos

  2. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas de acesso específicas
*/

-- Criar enum para status do jogo
CREATE TYPE game_status AS ENUM ('waiting', 'playing', 'finished');

-- Criar tabela de jogos
CREATE TABLE tic_tac_toe_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_x uuid REFERENCES auth.users(id),
  player_o uuid REFERENCES auth.users(id),
  current_turn uuid REFERENCES auth.users(id),
  winner uuid REFERENCES auth.users(id),
  status game_status DEFAULT 'waiting',
  board jsonb DEFAULT '[null,null,null,null,null,null,null,null,null]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar tabela de movimentos
CREATE TABLE tic_tac_toe_moves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES tic_tac_toe_games(id),
  player_id uuid REFERENCES auth.users(id),
  position integer NOT NULL,
  symbol text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE tic_tac_toe_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE tic_tac_toe_moves ENABLE ROW LEVEL SECURITY;

-- Políticas para jogos
CREATE POLICY "Jogadores podem ver seus jogos"
  ON tic_tac_toe_games
  FOR SELECT
  USING (
    auth.uid() = player_x OR 
    auth.uid() = player_o OR 
    status = 'waiting'
  );

CREATE POLICY "Jogadores podem atualizar seus jogos"
  ON tic_tac_toe_games
  FOR UPDATE
  USING (
    auth.uid() = player_x OR 
    auth.uid() = player_o
  )
  WITH CHECK (
    auth.uid() = current_turn
  );

-- Políticas para movimentos
CREATE POLICY "Jogadores podem ver movimentos dos seus jogos"
  ON tic_tac_toe_moves
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM tic_tac_toe_games
      WHERE id = game_id AND (
        auth.uid() = player_x OR 
        auth.uid() = player_o
      )
    )
  );

CREATE POLICY "Jogadores podem fazer movimentos na sua vez"
  ON tic_tac_toe_moves
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM tic_tac_toe_games
      WHERE id = game_id
      AND auth.uid() = current_turn
    )
  );

-- Função para verificar vitória
CREATE OR REPLACE FUNCTION check_winner(board jsonb)
RETURNS integer[] AS $$
DECLARE
  winning_combinations integer[][] := ARRAY[
    [0,1,2], [3,4,5], [6,7,8], -- Linhas
    [0,3,6], [1,4,7], [2,5,8], -- Colunas
    [0,4,8], [2,4,6]           -- Diagonais
  ];
  combination integer[];
BEGIN
  FOREACH combination IN ARRAY winning_combinations LOOP
    IF board->combination[1] = board->combination[2] 
    AND board->combination[2] = board->combination[3] 
    AND board->combination[1] IS NOT NULL THEN
      RETURN combination;
    END IF;
  END LOOP;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar o status do jogo
CREATE OR REPLACE FUNCTION update_game_status()
RETURNS TRIGGER AS $$
DECLARE
  winning_line integer[];
BEGIN
  -- Verificar vitória
  winning_line := check_winner(NEW.board);
  
  IF winning_line IS NOT NULL THEN
    NEW.status := 'finished';
    NEW.winner := NEW.current_turn;
  -- Verificar empate
  ELSIF NOT EXISTS (
    SELECT 1 
    FROM jsonb_array_elements(NEW.board) 
    WHERE value::text = 'null'
  ) THEN
    NEW.status := 'finished';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_game_status
  BEFORE UPDATE ON tic_tac_toe_games
  FOR EACH ROW
  EXECUTE FUNCTION update_game_status();

-- Índices para performance
CREATE INDEX idx_games_player_x ON tic_tac_toe_games(player_x);
CREATE INDEX idx_games_player_o ON tic_tac_toe_games(player_o);
CREATE INDEX idx_games_status ON tic_tac_toe_games(status);
CREATE INDEX idx_moves_game_id ON tic_tac_toe_moves(game_id);