/*
  # Atualizar cálculo de recompensa de afiliados

  1. Alterações
    - Atualiza a função process_affiliate_reward para calcular 1:20h (1.33 horas) para cada R$ 10,00
*/

-- Atualizar função de processamento de recompensa
CREATE OR REPLACE FUNCTION process_affiliate_reward(
  p_payment_id uuid,
  p_affiliate_code text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_referrer_id uuid;
  v_referred_id uuid;
  v_plan_price numeric;
  v_reward_hours numeric;
BEGIN
  -- Buscar IDs do afiliado e comprador
  SELECT al.user_id, p.user_id, pl.price
  INTO v_referrer_id, v_referred_id, v_plan_price
  FROM payments p
  JOIN affiliate_links al ON al.code = p_affiliate_code
  JOIN plans pl ON pl.id = p.plan_id
  WHERE p.id = p_payment_id;

  IF v_referrer_id IS NULL OR v_referred_id IS NULL THEN
    RAISE EXCEPTION 'Dados de afiliação inválidos';
  END IF;

  -- Calcular horas de recompensa (R$10 = 1.33 horas)
  v_reward_hours := (v_plan_price / 10) * 1.33;

  -- Registrar recompensa
  INSERT INTO affiliate_rewards (
    referrer_id,
    referred_id,
    payment_id,
    reward_hours
  ) VALUES (
    v_referrer_id,
    v_referred_id,
    p_payment_id,
    v_reward_hours::integer
  );

  -- Estender o plano do afiliado
  UPDATE profiles
  SET plan_expires_at = GREATEST(
    COALESCE(plan_expires_at, CURRENT_TIMESTAMP),
    CURRENT_TIMESTAMP
  ) + (v_reward_hours || ' hours')::interval
  WHERE id = v_referrer_id;

  -- Marcar recompensa como processada
  UPDATE affiliate_rewards
  SET processed = true
  WHERE payment_id = p_payment_id;
END;
$$;