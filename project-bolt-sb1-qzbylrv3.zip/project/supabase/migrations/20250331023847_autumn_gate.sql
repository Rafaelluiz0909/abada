/*
  # Add room_name to tic_tac_toe_games

  1. Changes
    - Add room_name column to tic_tac_toe_games table
*/

-- Add room_name column
ALTER TABLE tic_tac_toe_games
ADD COLUMN IF NOT EXISTS room_name text;

-- Create index for room_name
CREATE INDEX IF NOT EXISTS idx_games_room_name 
ON tic_tac_toe_games(room_name);