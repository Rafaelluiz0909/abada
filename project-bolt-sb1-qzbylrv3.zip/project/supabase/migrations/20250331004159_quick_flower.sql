/*
  # Update User Plan to Trimestral

  1. Changes
    - Updates user's profile with "Plano Trimestral" plan type
    - Sets expiration date to 90 days (2160 hours) from now
    - Uses direct table update for reliability
*/

-- Update plan directly in profiles table
UPDATE profiles
SET 
  plan_type = 'Plano Trimestral',
  plan_expires_at = CURRENT_TIMESTAMP + interval '2160 hours',
  updated_at = CURRENT_TIMESTAMP
WHERE id IN (
  SELECT id 
  FROM auth.users 
  WHERE email = 'sandenss2016@gmail.com'
);

-- If no rows were updated, log a notice but don't fail the migration
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = 'sandenss2016@gmail.com'
  ) THEN
    RAISE NOTICE 'No user found with email sandenss2016@gmail.com';
  END IF;
END $$;