DO $$
DECLARE
  v_user_id uuid;
  v_wallet_id uuid;
BEGIN
  -- Buscar ID do usuário
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'teste01@gmail.com';

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Usuário não encontrado';
  END IF;

  -- Buscar ou criar carteira
  SELECT id INTO v_wallet_id
  FROM beta_game_wallets
  WHERE user_id = v_user_id;

  IF v_wallet_id IS NULL THEN
    -- Criar nova carteira
    INSERT INTO beta_game_wallets (
      user_id,
      balance,
      total_wagered,
      can_withdraw
    ) VALUES (
      v_user_id,
      5.00,
      0,
      false
    )
    RETURNING id INTO v_wallet_id;
  ELSE
    -- Atualizar carteira existente
    UPDATE beta_game_wallets
    SET 
      balance = balance + 5.00,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = v_wallet_id;
  END IF;

  -- Registrar transação
  INSERT INTO beta_game_transactions (
    wallet_id,
    type,
    amount
  ) VALUES (
    v_wallet_id,
    'deposit',
    5.00
  );

  RAISE NOTICE 'Saldo adicionado com sucesso para o usuário teste01@gmail.com';
END $$;