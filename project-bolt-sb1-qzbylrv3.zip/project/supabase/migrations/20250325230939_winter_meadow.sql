/*
  # Sistema de Indicação

  1. Novas Tabelas
    - `referral_codes`: Códigos de indicação únicos por usuário
    - `referral_rewards`: Registro de recompensas por indicação
    
  2. Novas Funções
    - `generate_referral_code`: Gera código único de indicação
    - `process_referral`: Processa uma indicação e aplica recompensa
    
  3. Alterações
    - Adiciona coluna referral_code na tabela payments
    
  4. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas de acesso específicas
*/

-- Criar tabela de códigos de indicação
CREATE TABLE referral_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  code text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Criar tabela de recompensas de indicação
CREATE TABLE referral_rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid REFERENCES auth.users(id) NOT NULL,
  referred_id uuid REFERENCES auth.users(id) NOT NULL,
  payment_id uuid REFERENCES payments(id) NOT NULL,
  reward_hours integer NOT NULL,
  processed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Adicionar coluna de código de indicação aos pagamentos
ALTER TABLE payments
ADD COLUMN referral_code text REFERENCES referral_codes(code);

-- Habilitar RLS
ALTER TABLE referral_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE referral_rewards ENABLE ROW LEVEL SECURITY;

-- Políticas de acesso
CREATE POLICY "Usuários podem ver seu próprio código" ON referral_codes
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem ver suas recompensas" ON referral_rewards
  FOR SELECT TO authenticated
  USING (auth.uid() = referrer_id);

-- Função para gerar código de indicação
CREATE OR REPLACE FUNCTION generate_referral_code(user_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_code text;
  code_exists boolean;
BEGIN
  LOOP
    -- Gerar código aleatório de 8 caracteres
    new_code := upper(substring(md5(random()::text) from 1 for 8));
    
    -- Verificar se código já existe
    SELECT EXISTS (
      SELECT 1 FROM referral_codes WHERE code = new_code
    ) INTO code_exists;
    
    -- Se código não existe, usar este
    IF NOT code_exists THEN
      EXIT;
    END IF;
  END LOOP;

  -- Inserir novo código
  INSERT INTO referral_codes (user_id, code)
  VALUES (user_id, new_code)
  ON CONFLICT (user_id) DO UPDATE
  SET code = new_code;

  RETURN new_code;
END;
$$;

-- Função para processar indicação
CREATE OR REPLACE FUNCTION process_referral(
  payment_id uuid,
  referral_code text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_referrer_id uuid;
  v_referred_id uuid;
  v_plan_price numeric;
  v_reward_hours integer;
BEGIN
  -- Buscar IDs do indicador e indicado
  SELECT rc.user_id, p.user_id, pl.price
  INTO v_referrer_id, v_referred_id, v_plan_price
  FROM payments p
  JOIN referral_codes rc ON rc.code = referral_code
  JOIN plans pl ON pl.id = p.plan_id
  WHERE p.id = payment_id;

  -- Calcular horas de recompensa baseado no preço do plano
  -- Cada R$ 10 = 1 hora de recompensa
  v_reward_hours := (v_plan_price / 10)::integer;

  -- Registrar recompensa
  INSERT INTO referral_rewards (
    referrer_id,
    referred_id,
    payment_id,
    reward_hours
  ) VALUES (
    v_referrer_id,
    v_referred_id,
    payment_id,
    v_reward_hours
  );

  -- Estender o plano do indicador
  UPDATE profiles
  SET plan_expires_at = GREATEST(
    COALESCE(plan_expires_at, CURRENT_TIMESTAMP),
    CURRENT_TIMESTAMP
  ) + (v_reward_hours || ' hours')::interval
  WHERE id = v_referrer_id;

  -- Marcar recompensa como processada
  UPDATE referral_rewards
  SET processed = true
  WHERE payment_id = process_referral.payment_id;
END;
$$;

-- Trigger para processar indicação após pagamento aprovado
CREATE OR REPLACE FUNCTION process_referral_after_payment()
RETURNS TRIGGER AS $$
BEGIN
  -- Se pagamento foi aprovado e tem código de indicação
  IF NEW.status = 'completed' AND 
     OLD.status = 'pending' AND 
     NEW.referral_code IS NOT NULL THEN
    -- Processar indicação
    PERFORM process_referral(NEW.id, NEW.referral_code);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER process_referral_trigger
  AFTER UPDATE ON payments
  FOR EACH ROW
  WHEN (NEW.status = 'completed' AND OLD.status = 'pending')
  EXECUTE FUNCTION process_referral_after_payment();