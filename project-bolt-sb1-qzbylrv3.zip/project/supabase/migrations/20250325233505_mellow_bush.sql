/*
  # Correção do Trigger do Sistema de Indicação

  1. Alterações
    - Remove trigger existente antes de recriar
    - Mantém todas as outras funcionalidades

  2. Segurança
    - Mantém RLS ativo
    - Mantém políticas de acesso
*/

-- Remover trigger existente
DROP TRIGGER IF EXISTS process_referral_trigger ON payments;

-- Remover função do trigger existente
DROP FUNCTION IF EXISTS process_referral_after_payment();

-- Recriar função do trigger com nome mais específico
CREATE OR REPLACE FUNCTION public.handle_payment_referral()
RETURNS TRIGGER AS $$
BEGIN
  -- Se pagamento foi aprovado e tem código de indicação
  IF NEW.status = 'completed' AND 
     OLD.status = 'pending' AND 
     NEW.referral_code IS NOT NULL THEN
    -- Processar indicação
    PERFORM process_referral(NEW.id, NEW.referral_code);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar novo trigger com nome mais específico
CREATE TRIGGER handle_payment_referral_trigger
  AFTER UPDATE ON payments
  FOR EACH ROW
  WHEN (NEW.status = 'completed' AND OLD.status = 'pending')
  EXECUTE FUNCTION handle_payment_referral();