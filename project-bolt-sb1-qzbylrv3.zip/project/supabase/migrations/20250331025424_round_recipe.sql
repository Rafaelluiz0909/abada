/*
  # Sistema de Damas Multiplayer

  1. Novas Tabelas
    - `checkers_games`: Armazena as partidas
    - `checkers_moves`: Armazena os movimentos

  2. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas de acesso específicas
*/

-- Criar tabela de jogos de damas
CREATE TABLE checkers_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_white uuid REFERENCES auth.users(id),
  player_black uuid REFERENCES auth.users(id),
  current_turn uuid REFERENCES auth.users(id),
  winner uuid REFERENCES auth.users(id),
  status game_status DEFAULT 'waiting',
  board jsonb DEFAULT '[
    [null,"B",null,"B",null,"B",null,"B"],
    ["B",null,"B",null,"B",null,"B",null],
    [null,"B",null,"B",null,"B",null,"B"],
    [null,null,null,null,null,null,null,null],
    [null,null,null,null,null,null,null,null],
    ["W",null,"W",null,"W",null,"W",null],
    [null,"W",null,"W",null,"W",null,"W"],
    ["W",null,"W",null,"W",null,"W",null]
  ]',
  room_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar tabela de movimentos
CREATE TABLE checkers_moves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES checkers_games(id),
  player_id uuid REFERENCES auth.users(id),
  from_position jsonb NOT NULL, -- [row, col]
  to_position jsonb NOT NULL,   -- [row, col]
  captured_position jsonb,      -- [row, col] se uma peça foi capturada
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE checkers_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE checkers_moves ENABLE ROW LEVEL SECURITY;

-- Políticas para jogos
CREATE POLICY "Jogadores podem ver jogos disponíveis ou próprios"
  ON checkers_games
  FOR SELECT
  TO public
  USING (
    status = 'waiting' OR 
    auth.uid() = player_white OR 
    auth.uid() = player_black
  );

CREATE POLICY "Jogadores podem criar jogos"
  ON checkers_games
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = player_white);

CREATE POLICY "Jogadores podem atualizar seus jogos"
  ON checkers_games
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() IN (player_white, player_black)
  )
  WITH CHECK (
    CASE
      WHEN auth.uid() = player_white AND player_black IS NULL THEN true
      WHEN auth.uid() = current_turn THEN true
      ELSE false
    END
  );

-- Políticas para movimentos
CREATE POLICY "Jogadores podem ver movimentos dos seus jogos"
  ON checkers_moves
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM checkers_games
      WHERE id = game_id AND (
        auth.uid() = player_white OR 
        auth.uid() = player_black
      )
    )
  );

CREATE POLICY "Jogadores podem fazer movimentos na sua vez"
  ON checkers_moves
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM checkers_games
      WHERE id = game_id
      AND auth.uid() = current_turn
    )
  );

-- Índices para performance
CREATE INDEX idx_checkers_games_player_white ON checkers_games(player_white);
CREATE INDEX idx_checkers_games_player_black ON checkers_games(player_black);
CREATE INDEX idx_checkers_games_status ON checkers_games(status);
CREATE INDEX idx_checkers_moves_game_id ON checkers_moves(game_id);