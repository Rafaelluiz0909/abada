import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

// Inicializar cliente Supabase
const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
  {
    auth: {
      persistSession: false,
    }
  }
);

async function processPayment(payload: any) {
  try {
    console.log('Iniciando processamento de pagamento:', payload);

    // Registrar webhook
    const { data: webhook, error: webhookError } = await supabaseClient
      .from('payment_webhooks')
      .insert({
        transaction_id: payload.idTransaction,
        event_type: payload.status,
        payload: payload,
      })
      .select()
      .single();

    if (webhookError) {
      console.error('Erro ao registrar webhook:', webhookError);
      throw webhookError;
    }

    console.log('Webhook registrado com sucesso:', webhook);

    // Se o pagamento foi aprovado
    if (payload.status === 'approved') {
      console.log('Pagamento aprovado, buscando detalhes...');

      // Buscar pagamento pelo transaction_id
      const { data: payment, error: paymentError } = await supabaseClient
        .from('payments')
        .select('*, metadata')
        .eq('transaction_id', payload.idTransaction)
        .single();

      if (paymentError) {
        console.error('Erro ao buscar pagamento:', paymentError);
        throw paymentError;
      }

      if (!payment) {
        console.error('Pagamento não encontrado para transaction_id:', payload.idTransaction);
        throw new Error('Pagamento não encontrado');
      }

      console.log('Pagamento encontrado:', payment);

      // Atualizar status do pagamento
      const { error: updateError } = await supabaseClient
        .from('payments')
        .update({
          status: 'completed',
          paid_at: new Date().toISOString(),
        })
        .eq('id', payment.id);

      if (updateError) {
        console.error('Erro ao atualizar status do pagamento:', updateError);
        throw updateError;
      }

      console.log('Status do pagamento atualizado para completed');

      // Se for um depósito para jogos beta
      if (payment.metadata?.type === 'deposit') {
        console.log('Processando depósito para jogos beta');

        // Buscar ou criar carteira do usuário
        let wallet;
        const { data: existingWallet, error: walletError } = await supabaseClient
          .from('beta_game_wallets')
          .select('*')
          .eq('user_id', payment.user_id)
          .maybeSingle();

        if (walletError) {
          console.error('Erro ao buscar carteira:', walletError);
          throw walletError;
        }

        if (!existingWallet) {
          console.log('Criando nova carteira para usuário');
          const { data: newWallet, error: createError } = await supabaseClient
            .from('beta_game_wallets')
            .insert({
              user_id: payment.user_id,
              balance: payment.amount,
              total_wagered: 0,
              can_withdraw: false
            })
            .select()
            .single();

          if (createError) {
            console.error('Erro ao criar carteira:', createError);
            throw createError;
          }
          wallet = newWallet;
          console.log('Nova carteira criada:', wallet);
        } else {
          console.log('Atualizando carteira existente');
          wallet = existingWallet;
          // Atualizar saldo da carteira
          const { error: updateWalletError } = await supabaseClient
            .from('beta_game_wallets')
            .update({
              balance: existingWallet.balance + payment.amount,
              updated_at: new Date().toISOString()
            })
            .eq('id', existingWallet.id);

          if (updateWalletError) {
            console.error('Erro ao atualizar carteira:', updateWalletError);
            throw updateWalletError;
          }
          console.log('Carteira atualizada com novo saldo');
        }

        console.log('Registrando transação');
        // Registrar transação
        const { error: transactionError } = await supabaseClient
          .from('beta_game_transactions')
          .insert({
            wallet_id: wallet.id,
            type: 'deposit',
            amount: payment.amount,
          });

        if (transactionError) {
          console.error('Erro ao registrar transação:', transactionError);
          throw transactionError;
        }
        console.log('Transação registrada com sucesso');
      }

      // Marcar webhook como processado
      await supabaseClient
        .from('payment_webhooks')
        .update({ processed: true })
        .eq('id', webhook.id);

      console.log('Webhook marcado como processado');
      return { success: true, message: 'Pagamento processado com sucesso' };
    }

    return { success: true, message: 'Webhook registrado' };
  } catch (error) {
    console.error('Erro ao processar pagamento:', error);
    throw error;
  }
}

Deno.serve(async (req) => {
  // Lidar com preflight OPTIONS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders,
    });
  }

  try {
    // Verificar método
    if (req.method !== 'POST') {
      throw new Error('Método não permitido');
    }

    // Verificar Content-Type
    const contentType = req.headers.get('content-type');
    if (!contentType?.includes('application/json')) {
      throw new Error('Content-Type deve ser application/json');
    }

    // Processar payload
    const payload = await req.json();
    console.log('Webhook recebido:', payload);
    const result = await processPayment(payload);

    return new Response(
      JSON.stringify(result),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  } catch (error) {
    console.error('Erro no webhook:', error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Erro interno do servidor',
      }),
      {
        status: error instanceof Error ? 400 : 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  }
});