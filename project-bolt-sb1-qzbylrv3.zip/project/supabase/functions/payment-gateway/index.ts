import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

const API_KEY = '6da2858faf08bc2456dc87b7';
const BASE_URL = 'https://api.syncpay.pro/v1/gateway/api/';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders,
    });
  }

  try {
    const paymentData = await req.json();
    const encodedApiKey = btoa(API_KEY);

    console.log('Dados recebidos:', paymentData);

    // Validar campos obrigatórios
    if (!paymentData.customer?.document) {
      return new Response(
        JSON.stringify({
          error: 'Campos obrigatórios faltando',
          missing_fields: ['cpf']
        }),
        {
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders,
          },
        }
      );
    }

    // Formatar dados conforme documentação da API
    const formattedData = {
      amount: Number(paymentData.amount).toFixed(2),
      customer: {
        name: paymentData.customer.name,
        email: paymentData.customer.email,
        document: paymentData.customer.document.replace(/\D/g, ''),
        phone: paymentData.customer.phone || null
      },
      pix: {
        expiresInDays: 2,
        key: 'random',
        description: paymentData.pix.description || 'Pagamento Atlas'
      },
      postbackUrl: paymentData.postbackUrl,
      metadata: paymentData.metadata
    };

    console.log('Dados formatados para API:', formattedData);

    // Fazer requisição para a API de pagamento
    const response = await fetch(BASE_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${encodedApiKey}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify(formattedData),
    });

    // Log da resposta bruta para debug
    const responseText = await response.text();
    console.log('Resposta bruta da API:', responseText);

    let responseData;
    try {
      responseData = JSON.parse(responseText);
    } catch (e) {
      console.error('Erro ao fazer parse da resposta:', e);
      throw new Error(`Resposta inválida da API: ${responseText}`);
    }

    if (!response.ok) {
      console.error('Erro na API:', responseData);
      return new Response(
        JSON.stringify({
          error: responseData.message || `Erro na API: ${response.status} ${response.statusText}`
        }),
        {
          status: response.status,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders,
          },
        }
      );
    }

    // Garantir que temos os campos necessários
    const paymentResponse = {
      idTransaction: responseData.idTransaction || responseData.id,
      paymentCode: responseData.paymentCode || responseData.pix?.qrCode,
      qrCode: responseData.qrCode || responseData.pix?.qrCode,
      paymentCodeBase64: responseData.paymentCodeBase64 || responseData.pix?.qrCodeBase64
    };

    // Validar campos obrigatórios na resposta
    if (!paymentResponse.paymentCode) {
      console.error('Resposta da API sem código PIX:', responseData);
      return new Response(
        JSON.stringify({
          error: 'Resposta da API incompleta',
          details: 'Código PIX não encontrado na resposta',
          apiResponse: responseData
        }),
        {
          status: 500,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders,
          },
        }
      );
    }

    console.log('Resposta processada:', paymentResponse);

    return new Response(
      JSON.stringify(paymentResponse),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  } catch (error) {
    console.error('Erro no gateway:', error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Erro interno do servidor',
        details: error instanceof Error ? error.stack : undefined
      }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  }
});