import { createClient } from 'npm:@supabase/supabase-js@2.39.7';
import OpenAI from 'npm:openai@4.28.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

const openai = new OpenAI({
  apiKey: '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',
});

const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
  {
    auth: {
      persistSession: false,
    }
  }
);

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: corsHeaders,
    });
  }

  try {
    const { message } = await req.json();

    // Verify message is present
    if (!message) {
      throw new Error('Mensagem não fornecida');
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        {
          role: "system",
          content: "Você é um assistente especializado em análise de roletas e apostas. Forneça orientações profissionais e éticas, focando em gestão responsável e estratégias baseadas em dados. Evite promessas de ganhos garantidos e mantenha um tom profissional e educativo."
        },
        {
          role: "user",
          content: message
        }
      ],
      temperature: 0.7,
      max_tokens: 500,
    });

    return new Response(
      JSON.stringify({
        response: completion.choices[0].message.content
      }),
      {
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Erro interno do servidor'
      }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    );
  }
});